package warehouse.io;

import org.junit.jupiter.api.Test;
import warehouse.entity.Product;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ProductFileReaderTest {

    @Test
    void readsOnlyValidLinesFromProjectDataFile() throws Exception {
        Path path = Paths.get("data", "products.txt");
        List<Product> products = ProductFileReader.readProducts(path);

        assertEquals(4, products.size());
        assertTrue(products.stream().anyMatch(p -> p.getId() == 1L));
        assertTrue(products.stream().anyMatch(p -> p.getId() == 2L));
        assertTrue(products.stream().anyMatch(p -> p.getId() == 6L));
        assertTrue(products.stream().anyMatch(p -> p.getId() == 7L));
    }
}
