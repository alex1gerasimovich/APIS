package warehouse.entity;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ProductTest {

    @Test
    void equalsAndHashCodeForSameData() {
        Product first = new Product(1L, "Ноутбук", 10, 999.99);
        Product second = new Product(1L, "Ноутбук", 10, 999.99);

        assertEquals(first, second);
        assertEquals(first.hashCode(), second.hashCode());
    }

    @Test
    void notEqualWhenIdDiffers() {
        Product first = new Product(1L, "Ноутбук", 10, 999.99);
        Product second = new Product(2L, "Ноутбук", 10, 999.99);

        assertNotEquals(first, second);
    }

    @Test
    void toStringContainsFields() {
        Product product = new Product(5L, "Монитор", 3, 200.0);
        String text = product.toString();

        assertTrue(text.contains("id=5"));
        assertTrue(text.contains("Монитор"));
        assertTrue(text.contains("quantity=3"));
    }
}
