package warehouse.facade;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import warehouse.entity.Product;
import warehouse.exception.ProductNotFoundException;
import warehouse.singleton.Warehouse;

import java.nio.file.Path;
import java.nio.file.Paths;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class WarehouseFacadeTest {

    private WarehouseFacade facade;

    @BeforeEach
    void setUp() {
        Warehouse.resetForTests();
        facade = new WarehouseFacade();
    }

    @AfterEach
    void tearDown() {
        Warehouse.resetForTests();
    }

    @Test
    void loadsFromFileAndBuildsReport() throws Exception {
        Path path = Paths.get("data", "products.txt");
        facade.loadProductsFromFile(path);

        assertEquals(4, facade.getAllProducts().size());
        String report = facade.formatInventoryReport();
        assertTrue(report.contains("--- Склад ---"));
        assertTrue(report.contains("Общая стоимость"));
    }

    @Test
    void addAndRemoveThroughFacade() throws Exception {
        facade.addProduct(new Product(10L, "Принтер", 2, 300.0));
        facade.removeProduct(10L);

        assertEquals(0, facade.getAllProducts().size());
    }

    @Test
    void removeMissingThroughFacade() throws Exception {
        assertThrows(ProductNotFoundException.class, () -> facade.removeProduct(404L));
    }
}
