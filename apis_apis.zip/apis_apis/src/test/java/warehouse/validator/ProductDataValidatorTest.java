package warehouse.validator;

import org.junit.jupiter.api.Test;
import warehouse.entity.Product;
import warehouse.exception.InvalidProductDataException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ProductDataValidatorTest {

    @Test
    void validLineParsed() throws InvalidProductDataException {
        Product product = ProductDataValidator.parseProduct("1;Ноутбук;10;999.99");

        assertEquals(1L, product.getId());
        assertEquals("Ноутбук", product.getName());
        assertEquals(10, product.getQuantity());
        assertEquals(999.99, product.getPricePerUnit(), 0.001);
    }

    @Test
    void invalidLinesRejected() {
        assertFalse(ProductDataValidator.isValidLine("broken"));
        assertFalse(ProductDataValidator.isValidLine("1;;5;10"));
        assertFalse(ProductDataValidator.isValidLine("2;Мышь;-1;19.99"));
        assertFalse(ProductDataValidator.isValidLine("3;Монитор;1;price"));
        assertFalse(ProductDataValidator.isValidLine("# comment"));
        assertFalse(ProductDataValidator.isValidLine(""));
    }

    @Test
    void parseThrowsOnInvalidData() {
        assertThrows(InvalidProductDataException.class,
                () -> ProductDataValidator.parseProduct("1;Товар;-5;10"));
    }
}
