package warehouse.validator;

import org.junit.jupiter.api.Test;
import warehouse.entity.Product;
import warehouse.exception.CalculationValidationException;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

class WarehouseCalculationValidatorTest {

    @Test
    void acceptsValidTotals() {
        assertDoesNotThrow(() -> WarehouseCalculationValidator.validateTotalQuantity(15));
        assertDoesNotThrow(() -> WarehouseCalculationValidator.validateTotalValue(1500.0));
    }

    @Test
    void rejectsNegativeTotals() {
        assertThrows(CalculationValidationException.class,
                () -> WarehouseCalculationValidator.validateTotalQuantity(-1));
        assertThrows(CalculationValidationException.class,
                () -> WarehouseCalculationValidator.validateTotalValue(-0.01));
    }

    @Test
    void validatesProductValue() {
        Product product = new Product(1L, "Стол", 2, 150.0);
        assertDoesNotThrow(() -> WarehouseCalculationValidator.validateProductValue(product));
    }
}
