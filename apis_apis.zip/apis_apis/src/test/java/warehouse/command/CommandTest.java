package warehouse.command;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import warehouse.entity.Product;
import warehouse.exception.ProductNotFoundException;
import warehouse.exception.WarehouseException;
import warehouse.singleton.Warehouse;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class CommandTest {

    private Warehouse warehouse;

    @BeforeEach
    void setUp() {
        Warehouse.resetForTests();
        warehouse = Warehouse.getInstance();
        warehouse.clearProducts();
    }

    @AfterEach
    void tearDown() {
        Warehouse.resetForTests();
    }

    @Test
    void addProductCommandAddsItem() throws WarehouseException {
        Product product = new Product(1L, "Ноутбук", 5, 100.0);
        new AddProductCommand(product, warehouse).execute();

        assertEquals(1, warehouse.getProductsSnapshot().size());
    }

    @Test
    void addDuplicateThrows() throws WarehouseException {
        Product product = new Product(1L, "Ноутбук", 5, 100.0);
        new AddProductCommand(product, warehouse).execute();

        assertThrows(WarehouseException.class, () -> new AddProductCommand(product, warehouse).execute());
    }

    @Test
    void removeProductCommandRemovesItem() throws WarehouseException {
        new AddProductCommand(new Product(2L, "Мышь", 1, 10.0), warehouse).execute();

        new RemoveProductCommand(2L, warehouse).execute();

        assertEquals(0, warehouse.getProductsSnapshot().size());
    }

    @Test
    void removeMissingThrows() {
        assertThrows(ProductNotFoundException.class, () -> new RemoveProductCommand(99L, warehouse).execute());
    }
}
