package warehouse.singleton;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertSame;

class WarehouseTest {

    @AfterEach
    void tearDown() {
        Warehouse.resetForTests();
    }

    @Test
    void returnsSameInstance() {
        Warehouse first = Warehouse.getInstance();
        Warehouse second = Warehouse.getInstance();

        assertSame(first, second);
    }
}
