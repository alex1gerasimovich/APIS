package warehouse.iterator;

import org.junit.jupiter.api.Test;
import warehouse.entity.Product;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ProductIteratorTest {

    @Test
    void iteratesAllProducts() {
        List<Product> products = List.of(
                new Product(1L, "A", 1, 1.0),
                new Product(2L, "B", 2, 2.0)
        );
        ProductIterator iterator = new ProductIterator(new ArrayList<>(products));
        List<Long> ids = new ArrayList<>();

        while (iterator.hasNext()) {
            ids.add(iterator.next().getId());
        }

        assertEquals(List.of(1L, 2L), ids);
        assertFalse(iterator.hasNext());
        assertThrows(NoSuchElementException.class, iterator::next);
    }
}
