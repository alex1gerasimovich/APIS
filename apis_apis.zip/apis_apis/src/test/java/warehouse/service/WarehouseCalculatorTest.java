package warehouse.service;

import org.junit.jupiter.api.Test;
import warehouse.entity.Product;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class WarehouseCalculatorTest {

    @Test
    void calculatesTotals() throws Exception {
        List<Product> products = List.of(
                new Product(1L, "A", 2, 10.0),
                new Product(2L, "B", 3, 5.0)
        );

        assertEquals(5, WarehouseCalculator.calculateTotalQuantity(products));
        assertEquals(35.0, WarehouseCalculator.calculateTotalValue(products), 0.001);
        assertEquals(20.0, WarehouseCalculator.calculateProductValue(products.get(0)), 0.001);
    }
}
