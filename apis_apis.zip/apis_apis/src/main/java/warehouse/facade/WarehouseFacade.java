package warehouse.facade;

import warehouse.command.AddProductCommand;
import warehouse.command.RemoveProductCommand;
import warehouse.command.WarehouseCommand;
import warehouse.entity.Product;
import warehouse.exception.CalculationValidationException;
import warehouse.exception.WarehouseException;
import warehouse.io.ProductFileReader;
import warehouse.iterator.ProductIterator;
import warehouse.service.WarehouseCalculator;
import warehouse.singleton.Warehouse;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Упрощённый интерфейс взаимодействия с системой управления складом (Facade).
 */
public class WarehouseFacade {

    private final Warehouse warehouse;

    public WarehouseFacade() {
        this.warehouse = Warehouse.getInstance();
    }

    public void loadProductsFromFile(Path filePath) throws IOException, WarehouseException {
        List<Product> loaded = ProductFileReader.readProducts(filePath);
        warehouse.clearProducts();
        for (Product product : loaded) {
            executeCommand(new AddProductCommand(product));
        }
    }

    public void addProduct(Product product) throws WarehouseException {
        executeCommand(new AddProductCommand(product));
    }

    public void removeProduct(long productId) throws WarehouseException {
        executeCommand(new RemoveProductCommand(productId));
    }

    public void executeCommand(WarehouseCommand command) throws WarehouseException {
        command.execute();
    }

    public List<Product> getAllProducts() {
        return warehouse.getProductsSnapshot();
    }

    public ProductIterator createProductIterator() {
        return new ProductIterator(warehouse.getProductsMutableCopy());
    }

    public int getTotalQuantity() throws CalculationValidationException {
        return WarehouseCalculator.calculateTotalQuantity(warehouse.getProductsSnapshot());
    }

    public double getTotalValue() throws CalculationValidationException {
        return WarehouseCalculator.calculateTotalValue(warehouse.getProductsSnapshot());
    }

    public String formatInventoryReport() throws CalculationValidationException {
        StringBuilder report = new StringBuilder();
        report.append("--- Склад ---").append(System.lineSeparator());
        ProductIterator iterator = createProductIterator();
        while (iterator.hasNext()) {
            Product product = iterator.next();
            double positionValue = WarehouseCalculator.calculateProductValue(product);
            report.append(product)
                    .append(", стоимость позиции=")
                    .append(positionValue)
                    .append(System.lineSeparator());
        }
        report.append("Всего единиц: ").append(getTotalQuantity()).append(System.lineSeparator());
        report.append("Общая стоимость: ").append(getTotalValue()).append(System.lineSeparator());
        return report.toString();
    }
}
