package warehouse.exception;

/**
 * Результат вычисления складских показателей не прошёл проверку.
 */
public class CalculationValidationException extends WarehouseException {

    public CalculationValidationException(String message) {
        super(message);
    }
}
