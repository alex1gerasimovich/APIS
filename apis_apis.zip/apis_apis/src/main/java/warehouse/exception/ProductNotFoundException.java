package warehouse.exception;

/**
 * Товар не найден на складе.
 */
public class ProductNotFoundException extends WarehouseException {

    public ProductNotFoundException(String message) {
        super(message);
    }
}
