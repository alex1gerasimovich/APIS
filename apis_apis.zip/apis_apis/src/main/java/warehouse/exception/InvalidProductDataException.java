package warehouse.exception;

/**
 * Некорректные исходные данные для создания товара.
 */
public class InvalidProductDataException extends WarehouseException {

    public InvalidProductDataException(String message) {
        super(message);
    }
}
