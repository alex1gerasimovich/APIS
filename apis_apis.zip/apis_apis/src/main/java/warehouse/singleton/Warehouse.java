package warehouse.singleton;

import warehouse.entity.Product;
import warehouse.exception.ProductNotFoundException;
import warehouse.exception.WarehouseException;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Единственный экземпляр склада (Singleton).
 */
public final class Warehouse {

    private static volatile Warehouse instance;
    private final List<Product> products;

    private Warehouse() {
        products = new ArrayList<>();
    }

    public static Warehouse getInstance() {
        if (instance == null) {
            synchronized (Warehouse.class) {
                if (instance == null) {
                    instance = new Warehouse();
                }
            }
        }
        return instance;
    }

    public static void resetForTests() {
        synchronized (Warehouse.class) {
            instance = null;
        }
    }

    public List<Product> getProductsSnapshot() {
        return Collections.unmodifiableList(new ArrayList<>(products));
    }

    public void clearProducts() {
        products.clear();
    }

    public void storeProduct(Product product) throws WarehouseException {
        for (Product existing : products) {
            if (existing.getId() == product.getId()) {
                throw new WarehouseException("Товар с id=" + product.getId() + " уже есть на складе");
            }
        }
        products.add(product);
    }

    public void deleteProduct(long productId) throws ProductNotFoundException {
        boolean removed = products.removeIf(p -> p.getId() == productId);
        if (!removed) {
            throw new ProductNotFoundException("Товар с id=" + productId + " не найден на складе");
        }
    }

    public List<Product> getProductsMutableCopy() {
        return new ArrayList<>(products);
    }
}
