package warehouse.io;

import warehouse.entity.Product;
import warehouse.exception.InvalidProductDataException;
import warehouse.validator.ProductDataValidator;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/**
 * Чтение товаров из текстового файла (Java 8+).
 */
public final class ProductFileReader {

    private ProductFileReader() {
    }

    public static List<Product> readProducts(Path filePath) throws IOException {
        List<Product> result = new ArrayList<>();
        try (Stream<String> lines = Files.lines(filePath)) {
            lines.forEach(line -> {
                try {
                    if (ProductDataValidator.isValidLine(line)) {
                        result.add(ProductDataValidator.parseProduct(line));
                    }
                } catch (InvalidProductDataException ignored) {
                    // переход к следующей строке
                }
            });
        }
        return result;
    }
}
