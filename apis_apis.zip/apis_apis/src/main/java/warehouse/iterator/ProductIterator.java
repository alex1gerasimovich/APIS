package warehouse.iterator;

import warehouse.entity.Product;

import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

/**
 * Итератор для обхода списка товаров на складе.
 */
public class ProductIterator implements Iterator<Product> {

    private final List<Product> products;
    private int index;

    public ProductIterator(List<Product> products) {
        this.products = products;
        this.index = 0;
    }

    @Override
    public boolean hasNext() {
        return index < products.size();
    }

    @Override
    public Product next() {
        if (!hasNext()) {
            throw new NoSuchElementException("Больше нет товаров для обхода");
        }
        return products.get(index++);
    }
}
