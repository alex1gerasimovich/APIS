package warehouse.entity;

/**
 * Товар на складе (только данные, без бизнес-логики).
 */
public class Product {

    private final long id;
    private final String name;
    private final int quantity;
    private final double pricePerUnit;

    public Product(long id, String name, int quantity, double pricePerUnit) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.pricePerUnit = pricePerUnit;
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getQuantity() {
        return quantity;
    }

    public double getPricePerUnit() {
        return pricePerUnit;
    }

    @Override
    public String toString() {
        return "Product{id=" + id
                + ", name='" + name + '\''
                + ", quantity=" + quantity
                + ", pricePerUnit=" + pricePerUnit
                + '}';
    }

    @Override
    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (this == other) {
            return true;
        }
        if (getClass() != other.getClass()) {
            return false;
        }
        Product that = (Product) other;
        return id == that.id
                && quantity == that.quantity
                && Double.compare(that.pricePerUnit, pricePerUnit) == 0
                && (name == null ? that.name == null : name.equals(that.name));
    }

    @Override
    public int hashCode() {
        int result = (int) (id ^ (id >>> 32));
        result = 31 * result + (name == null ? 0 : name.hashCode());
        result = 31 * result + quantity;
        long priceBits = Double.doubleToLongBits(pricePerUnit);
        result = 31 * result + (int) (priceBits ^ (priceBits >>> 32));
        return result;
    }
}
