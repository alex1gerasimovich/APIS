package warehouse.command;

import warehouse.exception.ProductNotFoundException;
import warehouse.exception.WarehouseException;
import warehouse.singleton.Warehouse;

/**
 * Команда удаления товара со склада.
 */
public class RemoveProductCommand implements WarehouseCommand {

    private final long productId;
    private final Warehouse warehouse;

    public RemoveProductCommand(long productId) {
        this(productId, Warehouse.getInstance());
    }

    RemoveProductCommand(long productId, Warehouse warehouse) {
        this.productId = productId;
        this.warehouse = warehouse;
    }

    @Override
    public void execute() throws WarehouseException {
        warehouse.deleteProduct(productId);
    }

    public long getProductId() {
        return productId;
    }
}
