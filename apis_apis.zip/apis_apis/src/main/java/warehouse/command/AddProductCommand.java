package warehouse.command;

import warehouse.entity.Product;
import warehouse.exception.WarehouseException;
import warehouse.singleton.Warehouse;

/**
 * Команда добавления товара на склад.
 */
public class AddProductCommand implements WarehouseCommand {

    private final Product product;
    private final Warehouse warehouse;

    public AddProductCommand(Product product) {
        this(product, Warehouse.getInstance());
    }

    AddProductCommand(Product product, Warehouse warehouse) {
        this.product = product;
        this.warehouse = warehouse;
    }

    @Override
    public void execute() throws WarehouseException {
        warehouse.storeProduct(product);
    }

    public Product getProduct() {
        return product;
    }
}
