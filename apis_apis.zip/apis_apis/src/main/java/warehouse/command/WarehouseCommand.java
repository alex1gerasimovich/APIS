package warehouse.command;

import warehouse.exception.WarehouseException;

/**
 * Команда операции со складом.
 */
public interface WarehouseCommand {

    void execute() throws WarehouseException;
}
