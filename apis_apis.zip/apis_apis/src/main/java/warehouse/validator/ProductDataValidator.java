package warehouse.validator;

import warehouse.entity.Product;
import warehouse.exception.InvalidProductDataException;

/**
 * Валидация исходных данных для создания {@link Product}.
 */
public final class ProductDataValidator {

    private static final int EXPECTED_FIELD_COUNT = 4;
    private static final String DELIMITER = ";";

    private ProductDataValidator() {
    }

    public static boolean isValidLine(String line) {
        if (line == null) {
            return false;
        }
        String trimmed = line.trim();
        if (trimmed.isEmpty() || trimmed.startsWith("#")) {
            return false;
        }
        String[] parts = trimmed.split(DELIMITER, -1);
        if (parts.length != EXPECTED_FIELD_COUNT) {
            return false;
        }
        try {
            validateAndParse(parts);
            return true;
        } catch (InvalidProductDataException e) {
            return false;
        }
    }

    public static Product parseProduct(String line) throws InvalidProductDataException {
        if (line == null) {
            throw new InvalidProductDataException("Строка не задана");
        }
        String trimmed = line.trim();
        if (trimmed.isEmpty() || trimmed.startsWith("#")) {
            throw new InvalidProductDataException("Пустая или служебная строка");
        }
        String[] parts = trimmed.split(DELIMITER, -1);
        if (parts.length != EXPECTED_FIELD_COUNT) {
            throw new InvalidProductDataException(
                    "Ожидается " + EXPECTED_FIELD_COUNT + " поля, получено: " + parts.length);
        }
        return validateAndParse(parts);
    }

    private static Product validateAndParse(String[] parts) throws InvalidProductDataException {
        long id = parseId(parts[0]);
        String name = parseName(parts[1]);
        int quantity = parseQuantity(parts[2]);
        double price = parsePrice(parts[3]);
        return new Product(id, name, quantity, price);
    }

    private static long parseId(String raw) throws InvalidProductDataException {
        try {
            long id = Long.parseLong(raw.trim());
            if (id <= 0) {
                throw new InvalidProductDataException("Идентификатор должен быть положительным: " + raw);
            }
            return id;
        } catch (NumberFormatException e) {
            throw new InvalidProductDataException("Некорректный идентификатор: " + raw);
        }
    }

    private static String parseName(String raw) throws InvalidProductDataException {
        String name = raw.trim();
        if (name.isEmpty()) {
            throw new InvalidProductDataException("Наименование не может быть пустым");
        }
        return name;
    }

    private static int parseQuantity(String raw) throws InvalidProductDataException {
        try {
            int quantity = Integer.parseInt(raw.trim());
            if (quantity < 0) {
                throw new InvalidProductDataException("Количество не может быть отрицательным: " + raw);
            }
            return quantity;
        } catch (NumberFormatException e) {
            throw new InvalidProductDataException("Некорректное количество: " + raw);
        }
    }

    private static double parsePrice(String raw) throws InvalidProductDataException {
        try {
            double price = Double.parseDouble(raw.trim());
            if (price < 0) {
                throw new InvalidProductDataException("Цена не может быть отрицательной: " + raw);
            }
            if (Double.isInfinite(price) || Double.isNaN(price)) {
                throw new InvalidProductDataException("Некорректная цена: " + raw);
            }
            return price;
        } catch (NumberFormatException e) {
            throw new InvalidProductDataException("Некорректная цена: " + raw);
        }
    }
}
