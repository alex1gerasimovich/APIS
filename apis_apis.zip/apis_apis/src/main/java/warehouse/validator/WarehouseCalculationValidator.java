package warehouse.validator;

import warehouse.entity.Product;
import warehouse.exception.CalculationValidationException;

import java.util.List;

/**
 * Проверка результатов вычислений складских показателей.
 */
public final class WarehouseCalculationValidator {

    private WarehouseCalculationValidator() {
    }

    public static void validateTotalQuantity(int totalQuantity) throws CalculationValidationException {
        if (totalQuantity < 0) {
            throw new CalculationValidationException(
                    "Суммарное количество не может быть отрицательным: " + totalQuantity);
        }
    }

    public static void validateTotalValue(double totalValue) throws CalculationValidationException {
        if (totalValue < 0) {
            throw new CalculationValidationException(
                    "Суммарная стоимость не может быть отрицательной: " + totalValue);
        }
        if (Double.isInfinite(totalValue) || Double.isNaN(totalValue)) {
            throw new CalculationValidationException("Некорректная суммарная стоимость: " + totalValue);
        }
    }

    public static void validateProductValue(Product product) throws CalculationValidationException {
        double value = product.getQuantity() * product.getPricePerUnit();
        if (value < 0) {
            throw new CalculationValidationException(
                    "Стоимость позиции не может быть отрицательной для товара id=" + product.getId());
        }
        if (Double.isInfinite(value) || Double.isNaN(value)) {
            throw new CalculationValidationException(
                    "Некорректная стоимость позиции для товара id=" + product.getId());
        }
    }

    public static void validateAllProductValues(List<Product> products) throws CalculationValidationException {
        for (Product product : products) {
            validateProductValue(product);
        }
    }
}
