package warehouse;

import warehouse.entity.Product;
import warehouse.exception.WarehouseException;
import warehouse.facade.WarehouseFacade;
import warehouse.iterator.ProductIterator;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Точка входа: демонстрация системы управления складом.
 * <p>
 * Запуск: {@code warehouse.Main} или {@code mvn exec:java}.
 * Аргумент (необязательно): путь к файлу данных, например {@code data/products.txt}.
 */
public class Main {

    private static final Path DEFAULT_DATA_FILE = Paths.get("data", "products.txt");

    public static void main(String[] args) {
        Path dataFile = resolveDataFile(args);
        WarehouseFacade facade = new WarehouseFacade();

        System.out.println("=== Система управления складом ===");
        System.out.println();

        if (!Files.isRegularFile(dataFile)) {
            System.err.println("Файл не найден: " + dataFile.toAbsolutePath());
            System.err.println("Запускайте приложение из корня проекта (где лежит папка data).");
            return;
        }

        try {
            System.out.println("1. Загрузка товаров из файла (Facade + чтение Java 8+):");
            System.out.println("   " + dataFile.toAbsolutePath());
            facade.loadProductsFromFile(dataFile);
            printInventory("   Состояние после загрузки", facade);

            System.out.println("2. Добавление товара (Command — AddProductCommand):");
            facade.addProduct(new Product(8L, "Принтер", 2, 320.00));
            System.out.println("   Добавлен: id=8, Принтер, qty=2, price=320.00");

            System.out.println("3. Удаление товара (Command — RemoveProductCommand):");
            facade.removeProduct(2L);
            System.out.println("   Удалён товар с id=2");

            System.out.println("4. Обход склада (Iterator — ProductIterator):");
            ProductIterator iterator = facade.createProductIterator();
            int index = 1;
            while (iterator.hasNext()) {
                Product product = iterator.next();
                System.out.println("   [" + index++ + "] " + product.getName()
                        + " (id=" + product.getId()
                        + ", qty=" + product.getQuantity() + ")");
            }

            System.out.println();
            printInventory("5. Итоговый отчёт (Facade)", facade);

        } catch (WarehouseException e) {
            System.err.println("Ошибка склада: " + e.getMessage());
        } catch (java.io.IOException e) {
            System.err.println("Ошибка чтения файла: " + e.getMessage());
        }
    }

    private static Path resolveDataFile(String[] args) {
        if (args != null && args.length > 0 && args[0] != null && !args[0].isBlank()) {
            return Paths.get(args[0].trim());
        }
        return DEFAULT_DATA_FILE;
    }

    private static void printInventory(String title, WarehouseFacade facade) throws WarehouseException {
        System.out.println();
        System.out.println(title + ":");
        System.out.println(facade.formatInventoryReport());
    }
}
