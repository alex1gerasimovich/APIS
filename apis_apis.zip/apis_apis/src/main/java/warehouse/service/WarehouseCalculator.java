package warehouse.service;

import warehouse.entity.Product;
import warehouse.exception.CalculationValidationException;
import warehouse.validator.WarehouseCalculationValidator;

import java.util.List;

/**
 * Вычисление складских показателей (вне entity-классов).
 */
public final class WarehouseCalculator {

    private WarehouseCalculator() {
    }

    public static int calculateTotalQuantity(List<Product> products) throws CalculationValidationException {
        int total = 0;
        for (Product product : products) {
            total += product.getQuantity();
        }
        WarehouseCalculationValidator.validateTotalQuantity(total);
        return total;
    }

    public static double calculateTotalValue(List<Product> products) throws CalculationValidationException {
        WarehouseCalculationValidator.validateAllProductValues(products);
        double total = 0.0;
        for (Product product : products) {
            total += product.getQuantity() * product.getPricePerUnit();
        }
        WarehouseCalculationValidator.validateTotalValue(total);
        return total;
    }

    public static double calculateProductValue(Product product) throws CalculationValidationException {
        double value = product.getQuantity() * product.getPricePerUnit();
        WarehouseCalculationValidator.validateProductValue(product);
        return value;
    }
}
